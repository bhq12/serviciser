"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hello = void 0;
function hello(event) {
    console.log(`Received event: ${event}`);
    return event;
}
exports.hello = hello;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVsbG8tZnVuY3Rpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJoZWxsby1mdW5jdGlvbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxTQUFnQixLQUFLLENBQUMsS0FBYTtJQUNsQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixLQUFLLEVBQUUsQ0FBQyxDQUFDO0lBQ3hDLE9BQU8sS0FBSyxDQUFDO0FBQ2QsQ0FBQztBQUhELHNCQUdDIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGZ1bmN0aW9uIGhlbGxvKGV2ZW50OiBzdHJpbmcpIHtcblx0Y29uc29sZS5sb2coYFJlY2VpdmVkIGV2ZW50OiAke2V2ZW50fWApO1xuXHRyZXR1cm4gZXZlbnQ7XG59XG4iXX0=