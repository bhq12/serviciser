export function hello(event: string) {
	console.log(`Received event: ${event}`);
	return event;
}
