export declare function hello(event: string): string;
