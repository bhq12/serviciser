"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cdk = require("aws-cdk-lib");
const assertions_1 = require("aws-cdk-lib/assertions");
const Lambda = require("../../lib/lambda-stack");
test("SQS Queue and SNS Topic Created", () => {
    const app = new cdk.App();
    // WHEN
    const stack = new Lambda.LambdaStack(app, "MyTestStack");
    // THEN
    const template = assertions_1.Template.fromStack(stack);
    template.hasResourceProperties("AWS::SQS::Queue", {
        VisibilityTimeout: 300,
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFtYmRhLnRlc3QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJsYW1iZGEudGVzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLG1DQUFtQztBQUNuQyx1REFBeUQ7QUFDekQsaURBQWlEO0FBRWpELElBQUksQ0FBQyxpQ0FBaUMsRUFBRSxHQUFHLEVBQUU7SUFDNUMsTUFBTSxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7SUFDMUIsT0FBTztJQUNQLE1BQU0sS0FBSyxHQUFHLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFDekQsT0FBTztJQUVQLE1BQU0sUUFBUSxHQUFHLHFCQUFRLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBRTNDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxpQkFBaUIsRUFBRTtRQUNqRCxpQkFBaUIsRUFBRSxHQUFHO0tBQ3RCLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgY2RrIGZyb20gXCJhd3MtY2RrLWxpYlwiO1xuaW1wb3J0IHsgVGVtcGxhdGUsIE1hdGNoIH0gZnJvbSBcImF3cy1jZGstbGliL2Fzc2VydGlvbnNcIjtcbmltcG9ydCAqIGFzIExhbWJkYSBmcm9tIFwiLi4vLi4vbGliL2xhbWJkYS1zdGFja1wiO1xuXG50ZXN0KFwiU1FTIFF1ZXVlIGFuZCBTTlMgVG9waWMgQ3JlYXRlZFwiLCAoKSA9PiB7XG5cdGNvbnN0IGFwcCA9IG5ldyBjZGsuQXBwKCk7XG5cdC8vIFdIRU5cblx0Y29uc3Qgc3RhY2sgPSBuZXcgTGFtYmRhLkxhbWJkYVN0YWNrKGFwcCwgXCJNeVRlc3RTdGFja1wiKTtcblx0Ly8gVEhFTlxuXG5cdGNvbnN0IHRlbXBsYXRlID0gVGVtcGxhdGUuZnJvbVN0YWNrKHN0YWNrKTtcblxuXHR0ZW1wbGF0ZS5oYXNSZXNvdXJjZVByb3BlcnRpZXMoXCJBV1M6OlNRUzo6UXVldWVcIiwge1xuXHRcdFZpc2liaWxpdHlUaW1lb3V0OiAzMDAsXG5cdH0pO1xufSk7XG4iXX0=