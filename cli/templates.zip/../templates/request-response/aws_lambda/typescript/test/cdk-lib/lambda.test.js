"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cdk = require("aws-cdk-lib");
const assertions_1 = require("aws-cdk-lib/assertions");
const Lambda = require("../../lib/lambda-stack");
test("SQS Queue and SNS Topic Created", () => {
    const app = new cdk.App();
    // WHEN
    const stack = new Lambda.LambdaStack(app, "MyTestStack");
    // THEN
    const template = assertions_1.Template.fromStack(stack);
    template.hasResourceProperties("AWS::ApiGateway::RestApi", {
        Name: "HelloApi",
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFtYmRhLnRlc3QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJsYW1iZGEudGVzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLG1DQUFtQztBQUNuQyx1REFBeUQ7QUFDekQsaURBQWlEO0FBRWpELElBQUksQ0FBQyxpQ0FBaUMsRUFBRSxHQUFHLEVBQUU7SUFDNUMsTUFBTSxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7SUFDMUIsT0FBTztJQUNQLE1BQU0sS0FBSyxHQUFHLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFDekQsT0FBTztJQUVQLE1BQU0sUUFBUSxHQUFHLHFCQUFRLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBRTNDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQywwQkFBMEIsRUFBRTtRQUMxRCxJQUFJLEVBQUUsVUFBVTtLQUNoQixDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGNkayBmcm9tIFwiYXdzLWNkay1saWJcIjtcbmltcG9ydCB7IFRlbXBsYXRlLCBNYXRjaCB9IGZyb20gXCJhd3MtY2RrLWxpYi9hc3NlcnRpb25zXCI7XG5pbXBvcnQgKiBhcyBMYW1iZGEgZnJvbSBcIi4uLy4uL2xpYi9sYW1iZGEtc3RhY2tcIjtcblxudGVzdChcIlNRUyBRdWV1ZSBhbmQgU05TIFRvcGljIENyZWF0ZWRcIiwgKCkgPT4ge1xuXHRjb25zdCBhcHAgPSBuZXcgY2RrLkFwcCgpO1xuXHQvLyBXSEVOXG5cdGNvbnN0IHN0YWNrID0gbmV3IExhbWJkYS5MYW1iZGFTdGFjayhhcHAsIFwiTXlUZXN0U3RhY2tcIik7XG5cdC8vIFRIRU5cblxuXHRjb25zdCB0ZW1wbGF0ZSA9IFRlbXBsYXRlLmZyb21TdGFjayhzdGFjayk7XG5cblx0dGVtcGxhdGUuaGFzUmVzb3VyY2VQcm9wZXJ0aWVzKFwiQVdTOjpBcGlHYXRld2F5OjpSZXN0QXBpXCIsIHtcblx0XHROYW1lOiBcIkhlbGxvQXBpXCIsXG5cdH0pO1xufSk7XG4iXX0=